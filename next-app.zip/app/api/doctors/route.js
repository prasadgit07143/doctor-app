import { MongoClient } from "mongodb";
import { NextResponse } from "next/server";
import Doctor from "@/models/doctor";

export async function GET() {
  const client = new MongoClient(process.env.MONGODB_URI, {
    useNewUrlParser: true,
  });

  try {
    const sampleDoctors = [
      new Doctor({
        doctorId: 1001,
        email: "john.doe@gmail.com",
        name: "John Doe",
        password: "SecurePass1!",
        age: 35,
        gender: "Male",
        address: "123 Medical St, City",
        qualification: "MD, Cardiology",
        specialization: "Cardiology",
        experience: 10,
        contact: "7097018301",
        image: "/default-profile.jpg",
      }),
      new Doctor({
        doctorId: 1002,
        email: "mia.jasmine@gmail.com",
        name: "Mia Jasmine",
        password: "StrongPass2@",
        age: 30,
        gender: "Female",
        address: "456 Health Ave, Town",
        qualification: "DO, Pediatrics",
        specialization: "Pediatrics",
        experience: 8,
        contact: "1010118301",
        image: "/default-profile.jpg",
      }),
    ];

    await client.connect();
    const db = client.db("hms");

    const result = await db.collection("doctors").bulkWrite(
      sampleDoctors.map((doctor) => ({
        updateOne: {
          filter: { doctorId: doctor.doctorId },
          update: { $setOnInsert: doctor },
          upsert: true,
        },
      }))
    );
    const doctors = await db.collection("doctors").find({}).limit(20).toArray();
    return NextResponse.json(doctors);
  } catch (error) {
    console.log(error);
    return NextResponse.json(
      { error: "An error occurred while fetching doctors" },
      { status: 500 }
    );
  } finally {
    await client.close();
  }
}

export async function POST() {
  try {
    await client.connect();
    const db = client.db("hms");

    const sampleDoctors = [
      {
        doctorId: 1001,
        email: "john.doe@example.com",
        name: "John_Doe_MD",
        password: "SecurePass1!",
        gender: "Male",
        address: "123 Medical St, City",
        qualification: "MD, Cardiology",
        specialization: "Cardiology",
        experience: 10,
        image: "/default-profile.jpg",
      },
      {
        doctorId: 1002,
        email: "jane.smith@example.com",
        name: "Jane_Smith_DO",
        password: "StrongPass2@",
        gender: "Female",
        address: "456 Health Ave, Town",
        qualification: "DO, Pediatrics",
        specialization: "Pediatrics",
        experience: 8,
        image: "/default-profile.jpg",
      },
    ];

    const result = await db.collection("doctors").insertMany(sampleDoctors);
    return NextResponse.json({
      message: "Sample doctors added",
      insertedCount: result.insertedCount,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "An error occurred while adding sample doctors" },
      { status: 500 }
    );
  } finally {
    await client.close();
  }
}

export async function PUT() {
  return NextResponse.json({ message: "PUT request handled" });
}

export async function DELETE() {
  return NextResponse.json({ message: "DELETE request handled" });
}
