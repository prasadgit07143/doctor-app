import React from "react";

const HomePage = () => {
  return <div>This is HomePage</div>;
};

export default HomePage;
