import { MongoClient } from "mongodb";
import { NextResponse } from "next/server";

export async function GET() {
  const client = new MongoClient(process.env.MONGODB_URI, {
    useNewUrlParser: true,
  });

  try {
    const samplePatients = [
      {
        patientId: 2001,
        email: "john.doe@example.com",
        name: "John_Doe_MD",
        password: "SecurePass1!",
        gender: "Male",
        address: "123 Medical St, City",
        contactNumber: "123-456-7890",
        dateOfBirth: "1990-01-01",
        image: "/default-profile.jpg",
      },
      {
        patientId: 2002,
        email: "jane.smith@example.com",
        name: "Jane_Smith_DO",
        password: "StrongPass2@",
        gender: "Female",
        address: "456 Health Ave, Town",
        contactNumber: "987-654-3210",
        dateOfBirth: "1985-05-15",
        image: "/default-profile.jpg",
      },
    ];
    const result = await db.collection("patients").insertMany(samplePatients);

    await client.connect();
    const db = client.db("hms");
    const patients = await db
      .collection("patients")
      .find({})
      .limit(20)
      .toArray();
    return NextResponse.json(patients);
  } catch (error) {
    return NextResponse.json(
      { error: "An error occurred while fetching patients" },
      { status: 500 }
    );
  } finally {
    await client.close();
  }
}

export async function POST() {
  try {
    await client.connect();
    const db = client.db("hms");

    const samplePatients = [
      {
        patientId: 2001,
        email: "mc.donalds@example.com",
        name: "Donald",
        password: "SecurePass1!",
        age: 30,
        gender: "Male",
        address: "123 Medical St, City",
        phone: "5656565656",
        image: "/default-profile.jpg",
      },
      {
        patientId: 2002,
        email: "wanda.maximoff@example.com",
        name: "Wanda Maximoff",
        password: "StrongPass2@",
        age: 24,
        gender: "Female",
        address: "New York, USA",
        phone: "2611111111",
        image: "/default-profile.jpg",
      },
    ];

    const result = await db.collection("patients").insertMany(samplePatients);
    return NextResponse.json({
      message: "Sample patients added",
      insertedCount: result.insertedCount,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "An error occurred while adding sample patients" },
      { status: 500 }
    );
  } finally {
    await client.close();
  }
}

export async function PUT() {
  return NextResponse.json({ message: "PUT request handled" });
}

export async function DELETE() {
  return NextResponse.json({ message: "DELETE request handled" });
}
